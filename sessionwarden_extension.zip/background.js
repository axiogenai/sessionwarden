console.log('[SessionWarden BG] Service worker started.');

// Keep alive
setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);

// All Google-related domains for cookie clearing
const GOOGLE_DOMAINS = [
  '.google.com', '.google.co.uk', '.google.co.in', '.google.ca',
  '.google.com.au', '.google.de', '.google.fr', '.google.es',
  '.google.it', '.google.co.jp', '.google.com.br',
  '.youtube.com', '.gmail.com', '.googleusercontent.com',
  '.googleapis.com', '.gstatic.com', '.accounts.google.com',
  '.myaccount.google.com', '.docs.google.com', '.drive.google.com',
  '.calendar.google.com', '.meet.google.com', '.chat.google.com',
  '.colab.research.google.com', '.contacts.google.com',
  '.photos.google.com', '.maps.google.com', '.translate.google.com',
  '.news.google.com', '.play.google.com', '.cloud.google.com',
  '.console.cloud.google.com', '.firebase.google.com',
  '.googlesyndication.com', '.googleadservices.com',
  '.doubleclick.net', '.googletagmanager.com',
  '.google-analytics.com', '.appspot.com', '.firebaseapp.com',
  '.colab.google.com', '.kaggle.com', '.blogger.com',
  '.blogspot.com', '.chromium.org', '.withgoogle.com',
  '.web.whatsapp.com', '.facebook.com', '.twitter.com',
  '.x.com', '.instagram.com', '.linkedin.com', '.github.com',
  '.microsoft.com', '.live.com', '.outlook.com', '.office.com',
  '.netflix.com', '.amazon.com', '.reddit.com', '.discord.com'
];

function getCookieTypes(cookie) {
  const types = [];
  if (cookie.session) types.push('Session'); else types.push('Persistent');
  if (cookie.secure) types.push('Secure');
  if (cookie.httpOnly) types.push('HttpOnly');
  return types;
}

function getCookieCategory(name) {
  const n = name.toUpperCase();
  const auth = ['SID', 'HSID', 'SSID', 'SAPISID', 'APISID', 'LSID', 'OTZ', 'LOGIN_INFO'];
  const pref = ['NID', 'OGPC', 'PREF', 'UULE', 'CONSENT'];
  const analytics = ['_GA', '_GID', '_GAT', '__UTMA', '__UTMB', '__UTMC', '__UTMZ'];
  const ads = ['IDE', 'TEST_COOKIE', 'DSID', 'FPLC'];

  if (auth.some(a => n.includes(a))) return 'Authentication';
  if (pref.some(p => n.includes(p))) return 'Preferences';
  if (analytics.some(an => n.includes(an))) return 'Analytics';
  if (ads.some(ad => n.includes(ad))) return 'Marketing';
  return 'Functional';
}

async function clearAllCookies() {
  console.log('[SessionWarden BG] Clearing ALL cookies...');
  const clearedCookies = [];

  try {
    const allCookies = await chrome.cookies.getAll({});
    console.log(`[SessionWarden BG] Found ${allCookies.length} total cookies`);

    for (const cookie of allCookies) {
      const protocol = cookie.secure ? 'https://' : 'http://';
      const domain = cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
      const cookieUrl = protocol + domain + cookie.path;
      
      const details = {
        domain: cookie.domain,
        name: cookie.name,
        types: getCookieTypes(cookie),
        category: getCookieCategory(cookie.name)
      };

      try {
        const removeDetails = { url: cookieUrl, name: cookie.name, storeId: cookie.storeId };
        if (cookie.partitionKey) removeDetails.partitionKey = cookie.partitionKey;
        await chrome.cookies.remove(removeDetails);
        clearedCookies.push(details);
      } catch (e) {
        // Some cookies may resist removal
      }
    }
  } catch (e) {
    console.error('[SessionWarden BG] Cookie clearing error:', e);
  }

  console.log(`[SessionWarden BG] Cleared ${clearedCookies.length} cookies.`);
  return clearedCookies;
}

async function clearAllBrowsingData() {
  console.log('[SessionWarden BG] Clearing ALL browsing data...');

  return new Promise((resolve) => {
    chrome.browsingData.remove({
      since: 0,
      originTypes: {
        unprotectedWeb: true,
        protectedWeb: true,
        extension: true
      }
    }, {
      cookies: true,
      localStorage: true,
      indexedDB: true,
      serviceWorkers: true,
      cache: true,
      cacheStorage: true,
      webSQL: true
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('[SessionWarden BG] Browsing data error:', chrome.runtime.lastError.message);
      } else {
        console.log('[SessionWarden BG] All browsing data cleared.');
      }
      resolve();
    });
  });
}

async function closeAllTabsExceptDashboard(dashboardTabId) {
  console.log('[SessionWarden BG] Closing ALL tabs except dashboard...');

  const tabs = await chrome.tabs.query({});
  const closedTabs = [];
  const tabsToCloseIds = [];

  for (const tab of tabs) {
    if (dashboardTabId && tab.id === dashboardTabId) {
      console.log(`[SessionWarden BG] Keeping dashboard tab: ${tab.id}`);
      continue;
    }
    closedTabs.push({ title: tab.title || 'Untitled', url: tab.url || 'Unknown' });
    tabsToCloseIds.push(tab.id);
  }

  console.log(`[SessionWarden BG] Closing ${tabsToCloseIds.length} tabs...`);

  if (tabsToCloseIds.length > 0) {
    try {
      await chrome.tabs.remove(tabsToCloseIds);
    } catch (e) {
      console.warn('[SessionWarden BG] Batch close failed, trying one by one...');
      for (const tabId of tabsToCloseIds) {
        try {
          await chrome.tabs.remove(tabId);
        } catch (e2) {
          console.warn(`[SessionWarden BG] Could not close tab ${tabId}`);
        }
      }
    }
  }

  return closedTabs;
}

async function performFullLogout(dashboardTabId) {
  console.log('[SessionWarden BG] ========================================');
  console.log('[SessionWarden BG]    FULL LOGOUT INITIATED');
  console.log('[SessionWarden BG] ========================================');

  try {
    // Step 1: Clear ALL cookies (every website)
    console.log('[SessionWarden BG] Step 1/3: Clearing all cookies...');
    const cookiesClearedList = await clearAllCookies();

    // Step 2: Clear ALL browsing data
    console.log('[SessionWarden BG] Step 2/3: Clearing all browsing data...');
    await clearAllBrowsingData();

    // Step 3: Close ALL tabs except the dashboard
    console.log('[SessionWarden BG] Step 3/3: Closing all other tabs...');
    const closedTabsList = await closeAllTabsExceptDashboard(dashboardTabId);

    console.log('[SessionWarden BG] ========================================');
    console.log(`[SessionWarden BG]    LOGOUT COMPLETE`);
    console.log(`[SessionWarden BG]    Cookies: ${cookiesClearedList.length} | Tabs: ${closedTabsList.length}`);
    console.log('[SessionWarden BG] ========================================');

    return { 
      status: 'ok', 
      cookiesCleared: cookiesClearedList.length, 
      tabsClosed: closedTabsList.length,
      details: {
        cookies: cookiesClearedList,
        tabs: closedTabsList
      }
    };

  } catch (error) {
    console.error('[SessionWarden BG] LOGOUT ERROR:', error);
    return { status: 'error', message: error.message };
  }
}

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'perform_logout') {
    console.log('[SessionWarden BG] Logout request from tab:', sender.tab?.id);
    const dashboardTabId = sender.tab ? sender.tab.id : null;

    performFullLogout(dashboardTabId).then(result => {
      sendResponse(result);
    }).catch(err => {
      sendResponse({ status: 'error', message: err.message });
    });

    return true; // async response
  }

  if (message.action === 'ping') {
    sendResponse({ status: 'alive' });
    return true;
  }
});

console.log('[SessionWarden BG] Ready and listening.');