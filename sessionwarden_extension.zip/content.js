console.log('[SessionWarden] Content script loaded on:', window.location.href);

let logoutInProgress = false;

function triggerLogout() {
  // Prevent duplicate triggers
  if (logoutInProgress) {
    console.log('[SessionWarden] Logout already in progress, skipping...');
    return;
  }
  logoutInProgress = true;

  console.log('[SessionWarden] Sending perform_logout to background...');

  chrome.runtime.sendMessage({ action: 'perform_logout' }, (response) => {
    logoutInProgress = false;

    if (chrome.runtime.lastError) {
      console.error('[SessionWarden] Error:', chrome.runtime.lastError.message);
      window.postMessage({
        source: 'sessionwarden_extension',
        action: 'logout_complete',
        result: { status: 'error', message: chrome.runtime.lastError.message }
      }, '*');
      return;
    }

    console.log('[SessionWarden] Background response:', response);

    // Send result back to the web page
    window.postMessage({
      source: 'sessionwarden_extension',
      action: 'logout_complete',
      result: response
    }, '*');
  });
}

// Method 1: Watch for attribute change on <html>
const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    if (mutation.type === 'attributes' && mutation.attributeName === 'data-sw-logout') {
      console.log('[SessionWarden] data-sw-logout detected on <html>');
      triggerLogout();
    }
  }
});

observer.observe(document.documentElement, {
  attributes: true,
  attributeFilter: ['data-sw-logout']
});

// Method 2: Custom event listener
window.addEventListener('sessionwarden_trigger_logout', () => {
  console.log('[SessionWarden] Custom event received');
  triggerLogout();
});

// Method 3: postMessage listener
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (event.data?.source === 'sessionwarden_page') {
    if (event.data.action === 'perform_logout') {
      console.log('[SessionWarden] postMessage received for logout');
      triggerLogout();
    } else if (event.data.action === 'ping_extension') {
      console.log('[SessionWarden] postMessage received for ping');
      window.postMessage({
        source: 'sessionwarden_extension',
        action: 'extension_ready'
      }, '*');
    }
  }
});

// Ping background to verify connection
chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
  if (chrome.runtime.lastError) {
    console.warn('[SessionWarden] Extension not connected:', chrome.runtime.lastError.message);
  } else {
    console.log('[SessionWarden] Extension connected:', response);
    window.postMessage({
      source: 'sessionwarden_extension',
      action: 'extension_ready'
    }, '*');
  }
});

console.log('[SessionWarden] Content script ready.');